const cors = require('cors');
const bodyParser = require('body-parser');
const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.static('.')); // Serve HTML/CSS/JS files
app.use(bodyParser.json());

// Get Room List
app.get('/api/rooms', (req, res) => {
  res.json([
    { id: 1, name: 'Deluxe Room', price: 120 },
    { id: 2, name: 'Family Room', price: 150 },
    { id: 3, name: 'Executive Suite', price: 220 }
  ]);
});

// Subscribe API
app.post('/api/subscribe', (req, res) => {
  const email = req.body.email;
  if (!email) return res.status(400).json({ error: 'Email required' });

  const filePath = './data/subscribers.json';
  let subscribers = [];

  if (fs.existsSync(filePath)) {
    subscribers = JSON.parse(fs.readFileSync(filePath));
  }

  if (subscribers.includes(email)) {
    return res.status(400).json({ error: 'Email already subscribed' });
  }

  subscribers.push(email);
  fs.writeFileSync(filePath, JSON.stringify(subscribers, null, 2));
  res.json({ message: 'Subscribed successfully' });
});

// Placeholder route for Register
app.post('/api/register', (req, res) => {
  res.json({ message: 'Registration logic here' });
});

app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
const express = require('express');
const fs = require('fs');
const cors = require('cors');
const bodyParser = require('body-parser');
const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.static('.')); // Serve HTML/CSS/JS from this folder
app.use(bodyParser.json());

// Get Rooms
app.get('/api/rooms', (req, res) => {
  res.json([
    { id: 1, name: 'Deluxe Room', price: 120 },
    { id: 2, name: 'Family Room', price: 150 },
    { id: 3, name: 'Executive Suite', price: 220 }
  ]);
});

// Subscribe
app.post('/api/subscribe', (req, res) => {
  const email = req.body.email;
  if (!email) return res.status(400).json({ error: 'Email required' });

  const filePath = './data/subscribers.json';
  let subscribers = [];

  if (fs.existsSync(filePath)) {
    subscribers = JSON.parse(fs.readFileSync(filePath));
  }

  if (subscribers.includes(email)) {
    return res.status(400).json({ error: 'Email already subscribed' });
  }

  subscribers.push(email);
  fs.writeFileSync(filePath, JSON.stringify(subscribers, null, 2));
  res.json({ message: 'Subscribed successfully' });
});

app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
const express = require('express');
const fs = require('fs');
const cors = require('cors');
const bodyParser = require('body-parser');
const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.static('.')); // Serve HTML/CSS/JS from this folder
app.use(bodyParser.json());

// Get Rooms
app.get('/api/rooms', (req, res) => {
  res.json([
    { id: 1, name: 'Deluxe Room', price: 120 },
    { id: 2, name: 'Family Room', price: 150 },
    { id: 3, name: 'Executive Suite', price: 220 }
  ]);
});

// Subscribe
app.post('/api/subscribe', (req, res) => {
  const email = req.body.email;
  if (!email) return res.status(400).json({ error: 'Email required' });

  const filePath = './data/subscribers.json';
  let subscribers = [];

  if (fs.existsSync(filePath)) {
    subscribers = JSON.parse(fs.readFileSync(filePath));
  }

  if (subscribers.includes(email)) {
    return res.status(400).json({ error: 'Email already subscribed' });
  }

  subscribers.push(email);
  fs.writeFileSync(filePath, JSON.stringify(subscribers, null, 2));
  res.json({ message: 'Subscribed successfully' });
});

app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
